import express from "express";
import cors from "cors";
import { z } from "zod";
import {
  McpServer,
  type Tool,
  type Prompt,
  ListResourcesRequestSchema,
  ReadResourceRequestSchema,
  ListPromptsRequestSchema,
  GetPromptRequestSchema,
  CallToolRequestSchema
} from "@modelcontextprotocol/sdk/server/mcp.js";
import { StreamableHTTPServerTransport } from "@modelcontextprotocol/sdk/server/streamableHttp.js";

const app = express();
app.use(cors());
app.use(express.json());

const server = new McpServer(
  { name: "generic-mcp-server", version: "0.1.0" },
  { capabilities: { tools: {}, resources: {}, prompts: {} } }
);

const echoTool: Tool = {
  name: "echo",
  description: "Echo back a message.",
  inputSchema: z.object({ message: z.string() })
};

const nowTool: Tool = {
  name: "now",
  description: "Return server time in ISO 8601.",
  inputSchema: z.object({})
};

server.tools = [echoTool, nowTool];

server.setRequestHandler(CallToolRequestSchema, async (req) => {
  if (req.params.name === "echo") {
    const { message } = echoTool.inputSchema.parse(req.params.arguments ?? {});
    return { content: [{ type: "text", text: message }] };
  }
  if (req.params.name === "now") {
    return { content: [{ type: "text", text: new Date().toISOString() }] };
  }
  throw new Error(`Unknown tool: ${req.params.name}`);
});

const MOTD = `Welcome. Streamable HTTP is on. Try tools.echo, tools.now, resource:server:motd, prompt:hello.`;
server.setRequestHandler(ListResourcesRequestSchema, async () => ({
  resources: [{
    uri: "resource:server:motd",
    mimeType: "text/plain",
    name: "Server MOTD",
    description: "Built-in text resource."
  }]
}));
server.setRequestHandler(ReadResourceRequestSchema, async (req) => {
  if (req.params.uri !== "resource:server:motd") throw new Error("Unknown resource");
  return { contents: [{ uri: "resource:server:motd", mimeType: "text/plain", text: MOTD }] };
});

const helloPrompt: Prompt = {
  name: "hello",
  description: "Greet someone with a templated message.",
  arguments: [{ name: "name", description: "Name to greet", required: false }]
};
server.setRequestHandler(ListPromptsRequestSchema, async () => ({ prompts: [helloPrompt] }));
server.setRequestHandler(GetPromptRequestSchema, async (req) => {
  if (req.params.name !== "hello") throw new Error("Unknown prompt");
  const name = (req.params.arguments as any)?.name ?? "there";
  return { messages: [{ role: "user", content: [{ type: "text", text: `Hello, ${name}!` }] }] };
});

app.all("/mcp", async (req, res) => {
  const transport = new StreamableHTTPServerTransport({ req, res });
  await server.connect(transport, { clientHeaders: req.headers });
});

app.get("/healthz", (_req, res) => res.status(200).send("ok"));

const port = process.env.PORT || 8787;
app.listen(port, () => console.log(`MCP Streamable HTTP server running at :${port}/mcp`));
