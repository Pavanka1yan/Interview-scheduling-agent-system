import asyncio
import json
from mcp import Client
from mcp.types import ToolInvocation
from mcp.transport.http import StreamableHTTPClientTransport

BASE_URL = "http://localhost:8787/mcp"

async def main():
    transport = StreamableHTTPClientTransport(BASE_URL)
    async with transport:
        client = Client(transport)
        await client.initialize()

        tools = await client.list_tools()
        print("== Tools ==")
        for t in tools.tools:
            print(f"- {t.name}: {t.description}")

        print("\n== Call echo ==")
        resp = await client.call_tool(ToolInvocation(name="echo", arguments={"message": "ping"}))
        print(json.dumps(resp.model_dump(), indent=2))

        print("\n== Call now ==")
        resp = await client.call_tool(ToolInvocation(name="now", arguments={}))
        print(json.dumps(resp.model_dump(), indent=2))

        print("\n== Resources ==")
        rs = await client.list_resources()
        for r in rs.resources:
            print(f"- {r.uri}")

        print("\n== Read resource: motd ==")
        motd = await client.read_resource("resource:server:motd")
        print(json.dumps(motd.model_dump(), indent=2))

        print("\n== Prompts ==")
        ps = await client.list_prompts()
        for p in ps.prompts:
            print(f"- {p.name}")

        print("\n== Get prompt: hello(name='Kalyan') ==")
        prompt = await client.get_prompt("hello", {"name": "Kalyan"})
        print(json.dumps(prompt.model_dump(), indent=2))

        await client.shutdown()

if __name__ == "__main__":
    asyncio.run(main())
