
import os, json, re
import azure.functions as func
import requests
from msal import ConfidentialClientApplication
from html import unescape
import re as _re

TENANT_ID = os.getenv("AZ_TENANT_ID")
CLIENT_ID = os.getenv("AZ_CLIENT_ID")
CLIENT_SECRET = os.getenv("AZ_CLIENT_SECRET")
GRAPH_SCOPE = ["https://graph.microsoft.com/.default"]
CLIENT_STATE = os.getenv("GRAPH_CLIENT_STATE", "supersecret-state")
ORCH_BASE = os.getenv("ORCH_BASE", "http://localhost:8000")
ORCH_RESUME_PATH = os.getenv("ORCH_RESUME_PATH", "/resume")

def _graph_token():
    app = ConfidentialClientApplication(
        CLIENT_ID, authority=f"https://login.microsoftonline.com/{TENANT_ID}",
        client_credential=CLIENT_SECRET
    )
    result = app.acquire_token_silent(GRAPH_SCOPE, account=None)
    if not result:
        result = app.acquire_token_for_client(scopes=GRAPH_SCOPE)
    if "access_token" not in result:
        raise RuntimeError(f"MSAL error: {result}")
    return result["access_token"]

def _graph_get_message(user_id: str, message_id: str) -> dict:
    token = _graph_token()
    url = f"https://graph.microsoft.com/v1.0/users/{user_id}/messages/{message_id}"
    params = {
        "$select": "id,subject,conversationId,from,internetMessageId,bodyPreview,body",
        "$expand": "internetMessageHeaders"
    }
    r = requests.get(url, headers={"Authorization": f"Bearer {token}"}, params=params, timeout=15)
    r.raise_for_status()
    return r.json()

def _headers_to_dict(msg: dict) -> dict:
    headers = {}
    for h in msg.get("internetMessageHeaders", []):
        name = (h.get("name") or "").lower()
        headers[name] = h.get("value")
    return headers

def _extract_thread_id(msg: dict, headers: dict) -> str | None:
    xthread = headers.get("x-thread-key")
    if xthread:
        return xthread.strip()
    subj = msg.get("subject") or ""
    m = re.search(r"\[CID:(.*?)\]", subj)
    if m:
        cid = m.group(1).strip()
        return f"thread-{cid}"
    return None

def _clean_reply_text(html_body: dict | None, preview: str | None) -> str:
    text = ""
    if html_body and html_body.get("contentType") == "html":
        t = _re.sub(r"(?s)<(script|style).*?>.*?</\1>", "", html_body.get("content",""))
        t = _re.sub(r"(?s)<br\s*/?>", "\n", t)
        t = _re.sub(r"(?s)<.*?>", "", t)
        text = unescape(t)
    if not text:
        text = preview or ""
    lines = []
    for line in text.splitlines():
        if line.strip().startswith(">"):
            continue
        if "From:" in line and "Sent:" in line:
            break
        lines.append(line)
    return "\n".join(lines).strip()

def main(req: func.HttpRequest) -> func.HttpResponse:
    validation_token = req.params.get("validationToken")
    if validation_token:
        return func.HttpResponse(body=validation_token, mimetype="text/plain", status_code=200)

    try:
        payload = req.get_json()
    except Exception:
        return func.HttpResponse("Invalid JSON", status_code=400)

    notifs = payload.get("value", [])
    for n in notifs:
        if CLIENT_STATE and n.get("clientState") != CLIENT_STATE:
            continue

        resource = n.get("resource") or ""
        parts = resource.strip("/").split("/")
        user_id = None; message_id = None
        try:
            user_idx = parts.index("users") + 1
            msg_idx = parts.index("messages") + 1
            user_id = parts[user_idx]
            message_id = parts[msg_idx]
        except Exception:
            user_id = None
            message_id = n.get("resourceData", {}).get("id")

        if not message_id:
            continue

        try:
            msg = _graph_get_message(user_id, message_id) if user_id else {}
        except Exception:
            continue

        headers = _headers_to_dict(msg)
        thread_id = _extract_thread_id(msg, headers)
        if not thread_id:
            continue

        reply_text = _clean_reply_text(msg.get("body"), msg.get("bodyPreview"))

        try:
            requests.post(
                ORCH_BASE.rstrip("/") + ORCH_RESUME_PATH,
                json={"thread_id": thread_id, "reply_text": reply_text},
                timeout=10,
            )
        except Exception:
            pass

    return func.HttpResponse(status_code=202)
