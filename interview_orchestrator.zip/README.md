
# Interview Orchestrator (LLM-Supervisor, Plugin Messaging, Azure Functions)

End-to-end demo of an LLM-supervised multi-agent system built with **LangGraph** + **FastAPI**, featuring:

- **Supervisor (LLM)** orchestrating workers via handoff tools
- **Candidate Availability Agent**: sends email → **PAUSE** using interrupt → on `/resume` parses free-text with LLM and **persists availability**
- **Panel Selection Agent**: reads persisted availability, ranks mock panels, returns best choice
- **Plugin-based messaging**: switch between `smtp` and `mock` via `.env`
- **Typed config** with Pydantic v2 **BaseSettings** (reads `.env`)
- **Azure Functions** sample (`graph_mail_notify`) to receive Microsoft Graph **mail notifications** and call `/resume`

## Quick start

```bash
python -m venv .venv && source .venv/bin/activate   # or .venv\Scripts\activate on Windows
pip install -r requirements.txt
cp .env.example .env
# edit .env with your OPENAI_API_KEY, SMTP, etc.
uvicorn app.main:app --reload
```

In a separate terminal (or with a REST client):

1) Start a run (supervisor → candidate agent → pause):
```
POST http://localhost:8000/run
{"candidate_id":"CAND-001"}
```

2) When the real reply arrives (from Azure Function or manual testing), resume:
```
POST http://localhost:8000/resume
{"thread_id":"thread-CAND-001", "reply_text":"I can do Tue 15:00–16:00 IST or Wed 10:30–11:30 IST."}
```

Supervisor will then handoff to panel selection and return a concise summary.

## Azure Functions (Microsoft Graph Webhook)

The folder `azure_functions/graph_mail_notify` contains a Python **HTTP trigger** function that:
- handles Graph subscription validation
- receives notifications for new messages
- fetches the message via Graph, extracts our correlation key (`X-Thread-Key` or `[CID:...]`), cleans the reply text
- calls your FastAPI `/resume`

Deploy the Azure Function separately (it uses its own `requirements.txt`). Create/renew the Graph subscription from your favorite place (function, script, or portal).

## Plugin Messaging

The messaging layer is pluggable. In `.env`, set:

```
MESSAGING__PROVIDER=smtp   # or mock
```

SMTP config is under `SMTP__...` keys (see `.env.example`).

## Notes

- This project uses an in-memory checkpoint saver for simplicity. You can swap it to Postgres later.
- All external services (candidate store, panel DB) are mocked for clarity.
