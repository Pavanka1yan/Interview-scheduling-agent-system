
from __future__ import annotations
import re
from typing import Dict, Any, List
from pydantic import BaseModel, Field
from langchain.chat_models import init_chat_model
from langchain_core.tools import tool

# Mock candidate directory
CANDIDATES: Dict[str, Dict[str, Any]] = {
    "CAND-001": {"name": "Asha Rao",   "email": "asha.rao@example.com",   "skills": ["Python", "ML"]},
    "CAND-002": {"name": "Vikram Desai","email": "vikram.desai@example.com","skills": ["Java", "Cloud"]},
}

# In-memory availability store (thread_id -> payload)
AVAIL_STORE: Dict[str, Dict[str, Any]] = {}

# Panels mock
PANELS = [
    {"panel_id": "PANEL-A", "skills": ["Python", "ML"],   "timezone": "Asia/Kolkata"},
    {"panel_id": "PANEL-B", "skills": ["Java", "Cloud"],  "timezone": "Asia/Kolkata"},
    {"panel_id": "PANEL-C", "skills": ["Python", "Cloud"],"timezone": "Asia/Kolkata"},
]

# Global messaging provider injected at app startup
MESSAGING_PROVIDER = None

@tool
def fetch_candidate_details(candidate_id: str) -> dict:
    if candidate_id not in CANDIDATES:
        raise ValueError(f"Unknown candidate_id: {candidate_id}")
    return {"candidate_id": candidate_id, **CANDIDATES[candidate_id]}

@tool
def send_candidate_email(to: str, subject: str, body: str,
                         cc: list[str] | None = None,
                         bcc: list[str] | None = None) -> str:
    """Send an email via the selected messaging provider; returns deterministic thread_id.

    REQUIREMENT: subject MUST include [CID:<candidate_id>] marker.

    We also add X-Thread-Key header = thread-<CID>, so the Azure Function can correlate.

    """
    global MESSAGING_PROVIDER
    m = re.search(r"\[CID:(.*?)\]", subject or "")
    cid = (m.group(1).strip() if m else None) or "UNKNOWN"
    thread_id = f"thread-{cid}"
    headers = {"X-Thread-Key": thread_id}
    if MESSAGING_PROVIDER is None:
        raise RuntimeError("Messaging provider is not initialized.")
    MESSAGING_PROVIDER.send_email(to=to, subject=subject, body=body, cc=cc, bcc=bcc, headers=headers)
    return thread_id

# LLM structured parser for free-text availability
class Slot(BaseModel):
    date: str
    start_local: str
    end_local: str
    tz: str = "Asia/Kolkata"
    flexible: bool = False
    notes: str = ""

class AvailabilityExtraction(BaseModel):
    slots: list[Slot]
    confidence: float = Field(..., ge=0, le=1)
    normalized_to: str = "Asia/Kolkata"
    raw_excerpt: str

_llm = init_chat_model("openai:gpt-4o-mini", temperature=0)

@tool
def llm_parse_availability(email_text: str) -> dict:
    parser = _llm.with_structured_output(AvailabilityExtraction)
    prompt = (
        "Extract interview availability from the email. "
        "Use ISO dates (YYYY-MM-DD) and 24h HH:MM times; assume Asia/Kolkata if missing. "
        "Mark flexible=True for ranges/alternatives; include a short raw_excerpt."
    )
    result: AvailabilityExtraction = parser.invoke([
        {"role": "system", "content": prompt},
        {"role": "user", "content": email_text},
    ])
    return result.model_dump()

@tool
def persist_availability(thread_id: str, candidate_id: str, extraction: dict) -> str:
    AVAIL_STORE[thread_id] = {"candidate_id": candidate_id, "availability": extraction}
    return "ok"

@tool
def get_candidate_availability(thread_id: str) -> dict:
    if thread_id not in AVAIL_STORE:
        raise ValueError("No availability persisted for this thread_id")
    return AVAIL_STORE[thread_id]

@tool
def get_panel_list(candidate_id: str) -> list:
    return PANELS

@tool
def rank_panels(panels: list, candidate_skills: list, candidate_slots: list) -> dict:
    cs = set([s.lower() for s in (candidate_skills or [])])
    scored = []
    for p in panels:
        ps = set([s.lower() for s in p.get("skills", [])])
        score = len(cs.intersection(ps)) * 2
        scored.append({"panel_id": p["panel_id"], "skills": p["skills"], "score": score})
    scored.sort(key=lambda x: x["score"], reverse=True)
    best = scored[0] if scored else None
    return {"selected": best, "top3": scored[:3], "used_slots": candidate_slots}
