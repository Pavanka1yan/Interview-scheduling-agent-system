
from __future__ import annotations
from langgraph.graph import StateGraph, MessagesState, START, END
from langgraph.types import interrupt
from langgraph.checkpoint.memory import InMemorySaver

from .agents import supervisor_agent, candidate_availability_agent, panel_selection_agent

def await_reply_node(state: MessagesState):
    payload = interrupt({
        "reason": "waiting_for_candidate_reply",
        "instruction": "Resume with Command(resume={'reply_text': '...actual body...'})",
    })
    reply_text = (payload or {}).get("reply_text", "") if isinstance(payload, dict) else str(payload or "")
    injected = {
        "role": "user",
        "content": f"Candidate replied:\n\n{reply_text}\n\nPlease parse using llm_parse_availability and then persist."
    }
    return {"messages": [injected]}

def route_after_candidate(state: MessagesState) -> str:
    last = state["messages"][-1]
    content = last.get("content", "") if isinstance(last, dict) else str(last)
    if isinstance(content, list):
        content = " ".join([c.get("text", "") for c in content if isinstance(c, dict)])
    if "AWAIT_REPLY(" in str(content):
        return "await_reply"
    return "supervisor"

def build_app_graph():
    g = StateGraph(MessagesState)
    g.add_node(supervisor_agent, destinations=("candidate_availability_agent", "panel_selection_agent", END))
    g.add_node(candidate_availability_agent)
    g.add_node(panel_selection_agent)
    g.add_node("await_reply", await_reply_node)

    g.add_edge(START, "supervisor")
    g.add_conditional_edges("candidate_availability_agent", route_after_candidate,
                            {"await_reply": "await_reply", "supervisor": "supervisor"})
    g.add_edge("await_reply", "candidate_availability_agent")
    g.add_edge("candidate_availability_agent", "supervisor")
    g.add_edge("panel_selection_agent", "supervisor")

    app_graph = g.compile(checkpointer=InMemorySaver())
    return app_graph
