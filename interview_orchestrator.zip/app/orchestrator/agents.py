
from __future__ import annotations
from typing import Optional, Annotated
from langchain.chat_models import init_chat_model
from langgraph.prebuilt import create_react_agent, InjectedState
from langchain_core.tools import tool, InjectedToolCallId
from langgraph.types import Command
from .tools import (
    fetch_candidate_details, send_candidate_email, llm_parse_availability, persist_availability,
    get_candidate_availability, get_panel_list, rank_panels
)

LLM_SUP = init_chat_model("openai:gpt-4o-mini", temperature=0)
LLM = init_chat_model("openai:gpt-4o-mini", temperature=0)

# --- Candidate Availability Agent ---
candidate_tools = [fetch_candidate_details, send_candidate_email, llm_parse_availability, persist_availability]

candidate_availability_agent = create_react_agent(
    model=LLM,
    tools=candidate_tools,
    name="candidate_availability_agent",
    prompt=(
        "You are a candidate-availability agent.\n"
        "Protocol (TOOLS ONLY):\n"
        "1) Call fetch_candidate_details(candidate_id) to get name/email.\n"
        "2) Compose a concise email asking for availability. Include [CID:<candidate_id>] in SUBJECT.\n"
        "3) Call send_candidate_email(to, subject, body) and capture the returned thread_id.\n"
        "4) Immediately STOP and end your message with exactly one line:\n"
        "   AWAIT_REPLY(thread_id=<the_returned_thread_id>)\n"
        "5) When resumed with the candidate's reply text in the next user message, "
        "   call llm_parse_availability(email_text).\n"
        "6) Then call persist_availability(thread_id=<returned>, candidate_id=<id>, extraction=<tool_result>).\n"
        "7) End your message with exactly one line:\n"
        "   AVAILABILITY_READY(thread_id=<the_returned_thread_id>)\n"
        "Keep outputs concise."
    ),
)

# --- Panel Selection Agent ---
panel_tools = [get_candidate_availability, get_panel_list, rank_panels]

panel_selection_agent = create_react_agent(
    model=LLM,
    tools=panel_tools,
    name="panel_selection_agent",
    prompt=(
        "You are a panel selection agent.\n"
        "Goal: Choose the best interview panel for the candidate.\n"
        "Protocol (TOOLS ONLY):\n"
        "1) Call get_candidate_availability(thread_id) to get {'candidate_id','availability'}.\n"
        "2) Call get_panel_list(candidate_id) to fetch potential panels.\n"
        "3) Call rank_panels(panels, candidate_skills, candidate_slots) using candidate skills and the parsed slots.\n"
        "4) Return one JSON object on the last line with the 'selected' panel and 'top3'."
    ),
)

# --- LLM-driven Supervisor + handoff tools ---
def make_handoff_tool(agent_name: str, desc: Optional[str] = None):
    tool_name = f"handoff_to__{agent_name}"
    desc = desc or f"Delegate the task to {agent_name}."

    @tool(name=tool_name, description=desc)
    def _handoff(
        state: Annotated[dict, InjectedState],
        tool_call_id: Annotated[str, InjectedToolCallId],
    ) -> Command:
        return Command(
            goto=agent_name,
            update={"messages": state["messages"] + [{
                "role": "tool", "name": tool_name, "tool_call_id": tool_call_id,
                "content": f"Delegated to {agent_name}"
            }]},
            graph=Command.PARENT,
        )
    return _handoff

handoff_to_candidate = make_handoff_tool("candidate_availability_agent")
handoff_to_panel = make_handoff_tool("panel_selection_agent")

supervisor_agent = create_react_agent(
    model=LLM_SUP,
    tools=[handoff_to_candidate, handoff_to_panel],
    name="supervisor",
    prompt=(
        "You are the SUPERVISOR. You decide which specialist agent should run next.\n"
        "Rules:\n"
        "- Only use the handoff tools to delegate.\n"
        "- If availability has NOT been collected yet, delegate to candidate_availability_agent.\n"
        "- After the candidate agent reports AVAILABILITY_READY(...), delegate to panel_selection_agent.\n"
        "- When panel selection finishes, reply concisely with the chosen panel.\n"
        "Hints:\n"
        "- The candidate agent announces pause with AWAIT_REPLY(thread_id=...).\n"
        "- After resume and persistence, it prints AVAILABILITY_READY(thread_id=...).\n"
    ),
)
