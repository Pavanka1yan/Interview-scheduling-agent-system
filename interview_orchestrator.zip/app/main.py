
from __future__ import annotations
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from langgraph.types import Command
from langgraph.graph import MessagesState
from app.config.settings import AppSettings
from app.messaging.factory import get_messaging_provider
from app.orchestrator.graph import build_app_graph
from app.orchestrator.tools import CANDIDATES, MESSAGING_PROVIDER

app = FastAPI(title="LLM-Supervisor Orchestrator (Plugin Messaging, AzureFn-ready)")

# Build config & graph at startup
settings = AppSettings()
app_graph = build_app_graph()

# Initialize messaging provider and inject into tools module
MESSAGING_PROVIDER = get_messaging_provider(settings)  # type: ignore[attr-defined]

class RunRequest(BaseModel):
    candidate_id: str

class ResumeRequest(BaseModel):
    thread_id: str
    reply_text: str

@app.get("/health")
def health():
    return {"ok": True}

@app.post("/run")
def run_once(req: RunRequest):
    if req.candidate_id not in CANDIDATES:
        raise HTTPException(status_code=404, detail="Unknown candidate_id")
    thread_id = f"thread-{req.candidate_id}"
    cfg = {"configurable": {"thread_id": thread_id}}
    initial = MessagesState(messages=[{
        "role": "user",
        "content": f"For candidate_id {req.candidate_id}: email for availability, wait for reply, then select best panel."
    }])
    for _ in app_graph.stream(initial, cfg, stream_mode="updates"):  # pause after email
        pass
    return {"status": "started", "candidate_id": req.candidate_id, "thread_id": thread_id}

@app.post("/resume")
def resume(req: ResumeRequest):
    cfg = {"configurable": {"thread_id": req.thread_id}}
    cmd = Command(resume={"reply_text": req.reply_text})
    last_supervisor_msg = None
    for event in app_graph.stream(cmd, cfg, stream_mode="updates"):
        node = event.get("supervisor")
        if node and "messages" in node and node["messages"]:
            for m in reversed(node["messages"]):
                if m.get("role") == "assistant":
                    last_supervisor_msg = m.get("content")
                    break
    return {"status": "resumed", "thread_id": req.thread_id, "supervisor_summary": last_supervisor_msg}
