
from __future__ import annotations
from typing import Sequence, Mapping
from .base import MessagingProvider

class MockMessagingProvider(MessagingProvider):
    def send_email(self, *, to: str, subject: str, body: str,
                   cc: Sequence[str] | None = None,
                   bcc: Sequence[str] | None = None,
                   headers: Mapping[str, str] | None = None) -> None:
        print("""
[MOCK EMAIL SEND]
TO: {to}
CC: {cc}
BCC: {bcc}
SUBJECT: {subject}
HEADERS: {headers}
BODY:
{body}
""".format(to=to, cc=cc, bcc=bcc, subject=subject, headers=dict(headers or {}), body=body))
