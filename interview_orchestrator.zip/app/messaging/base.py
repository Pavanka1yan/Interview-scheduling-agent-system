
from __future__ import annotations
from abc import ABC, abstractmethod
from typing import Sequence, Mapping

class MessagingProvider(ABC):
    @abstractmethod
    def send_email(self, *, to: str, subject: str, body: str,
                   cc: Sequence[str] | None = None,
                   bcc: Sequence[str] | None = None,
                   headers: Mapping[str, str] | None = None) -> None:
        ...
