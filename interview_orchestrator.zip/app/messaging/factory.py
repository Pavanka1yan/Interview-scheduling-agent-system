
from __future__ import annotations
from .base import MessagingProvider
from .mock_provider import MockMessagingProvider
from .smtp_provider import SmtpMessagingProvider
from app.config.settings import AppSettings

def get_messaging_provider(settings: AppSettings) -> MessagingProvider:
    if settings.messaging.provider.lower() == "smtp":
        smtp = settings.smtp
        if not smtp.host or not smtp.username or not smtp.password:
            raise RuntimeError("SMTP provider selected but SMTP settings incomplete.")
        return SmtpMessagingProvider(
            host=smtp.host, port=smtp.port, use_ssl=smtp.use_ssl,
            username=smtp.username, password=smtp.password,
            from_email=smtp.from_email or smtp.username,
            from_name=smtp.from_name, dry_run=smtp.dry_run
        )
    # default
    return MockMessagingProvider()
