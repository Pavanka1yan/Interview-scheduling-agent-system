
from __future__ import annotations
import smtplib
from email.message import EmailMessage
from email.utils import formataddr
from typing import Sequence, Mapping

from .base import MessagingProvider

class SmtpMessagingProvider(MessagingProvider):
    def __init__(self, *, host: str, port: int, use_ssl: bool, username: str, password: str,
                 from_email: str, from_name: str, dry_run: bool = False):
        self.host = host
        self.port = port
        self.use_ssl = use_ssl
        self.username = username
        self.password = password
        self.from_email = from_email or username
        self.from_name = from_name
        self.dry_run = dry_run

    def send_email(self, *, to: str, subject: str, body: str,
                   cc: Sequence[str] | None = None,
                   bcc: Sequence[str] | None = None,
                   headers: Mapping[str, str] | None = None) -> None:
        if self.dry_run:
            print(f"[SMTP DRY RUN] To:{to} Subject:{subject} Headers:{headers}\n{body}\n")
            return

        msg = EmailMessage()
        msg["Subject"] = subject
        msg["From"] = formataddr((self.from_name, self.from_email))
        msg["To"] = to
        if cc:
            msg["Cc"] = ", ".join(cc)
        for k, v in (headers or {}).items():
            msg[k] = v
        recipients = [to] + list(cc or []) + list(bcc or [])
        msg.set_content(body)

        if self.use_ssl:
            with smtplib.SMTP_SSL(host=self.host, port=self.port, timeout=30) as s:
                s.login(self.username, self.password)
                s.send_message(msg, to_addrs=recipients)
        else:
            with smtplib.SMTP(host=self.host, port=self.port, timeout=30) as s:
                s.ehlo()
                try:
                    s.starttls()
                    s.ehlo()
                except smtplib.SMTPException:
                    pass
                s.login(self.username, self.password)
                s.send_message(msg, to_addrs=recipients)
