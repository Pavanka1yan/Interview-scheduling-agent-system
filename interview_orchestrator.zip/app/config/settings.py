
from __future__ import annotations
from pydantic import BaseModel, Field
from pydantic_settings import BaseSettings, SettingsConfigDict

class SMTPSettings(BaseModel):
    host: str | None = None
    port: int = 587
    use_ssl: bool = False
    username: str | None = None
    password: str | None = None
    from_email: str | None = None
    from_name: str = "Talent Bot"
    dry_run: bool = False

class MessagingSettings(BaseModel):
    provider: str = Field(default="mock", description="Options: smtp, mock")

class AzureSettings(BaseModel):
    tenant_id: str | None = None
    client_id: str | None = None
    client_secret: str | None = None
    graph_client_state: str = "supersecret-state"

class OrchestratorSettings(BaseModel):
    base_url: str = "http://localhost:8000"
    resume_path: str = "/resume"

class AppSettings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", env_nested_delimiter="__", extra="ignore")

    # OpenAI
    openai_api_key: str | None = None

    # Nested
    smtp: SMTPSettings = SMTPSettings()
    messaging: MessagingSettings = MessagingSettings()
    azure: AzureSettings = AzureSettings()
    orch: OrchestratorSettings = OrchestratorSettings()
